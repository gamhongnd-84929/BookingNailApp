package com.example.bookingnailserviceapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Button btnInfo = (Button) findViewById(R.id.btnStaffInfo);
        final Button btnChoose = (Button) findViewById(R.id.btnBook);
        final Button btnCheck = (Button) findViewById(R.id.btnCheckInfo);
        final Button btnService = (Button) findViewById(R.id.btnService);


        btnInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent iInfor = new Intent(MainActivity.this, StaffList.class);
                startActivity(iInfor);
            }
        });

        btnChoose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent iChoose = new Intent(MainActivity.this, Booking.class);
                startActivity(iChoose);

            }
        });

        btnCheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent iCheck = new Intent(MainActivity.this, CheckInfo.class);
                startActivity(iCheck);
            }
        });

        btnService.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent iservice = new Intent(MainActivity.this, ServicesList.class);
                startActivity(iservice);
            }
        });

    }
}
