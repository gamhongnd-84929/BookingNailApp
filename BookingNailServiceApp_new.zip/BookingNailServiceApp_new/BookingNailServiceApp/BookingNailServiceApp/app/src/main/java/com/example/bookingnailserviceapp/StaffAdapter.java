package com.example.bookingnailserviceapp;

import android.content.Context;
import android.content.Intent;
import android.content.res.AssetManager;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public class StaffAdapter extends RecyclerView.Adapter<StaffAdapter.ViewHolder> {

    public static final String STAFF_KEY="staff_key";
    private List<Staff> staffList;
    private Context sContext;
    private AssetManager assetManager;

    public StaffAdapter(Context context, List<Staff> sList)
    {
        this.sContext = context;
        this.staffList = sList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.staff_layout,parent,false);
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        final Staff staff = staffList.get(position);

        try{
            holder.staffName.setText(staff.getStaffName());
            String imageFile = staff.getImage();
            InputStream is = sContext.getAssets().open("staffimages/"+imageFile);
            Drawable d = Drawable.createFromStream(is,null);
            holder.staffImage.setImageDrawable(d);

        } catch (IOException e) {
            e.printStackTrace();
        }

        holder.sView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(sContext,StaffDetails.class);
                intent.putExtra(STAFF_KEY,staff);
                sContext.startActivity(intent);
            }
        });

    }



    @Override
    public int getItemCount() {
        return staffList.size();
    }



    public class ViewHolder extends RecyclerView.ViewHolder {
        public ImageView staffImage;
        public TextView staffName;
        public TextView position;
        public View sView;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            staffImage =(ImageView) itemView.findViewById(R.id.imageStaff);
            staffName = (TextView) itemView.findViewById(R.id.txtName);

            sView = itemView;

        }
    }
}
