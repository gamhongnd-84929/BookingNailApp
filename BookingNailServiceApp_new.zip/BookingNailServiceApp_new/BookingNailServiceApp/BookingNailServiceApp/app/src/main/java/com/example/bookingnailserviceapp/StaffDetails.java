package com.example.bookingnailserviceapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;

public class StaffDetails extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staff_details);

        Staff staff = getIntent().getExtras().getParcelable(StaffAdapter.STAFF_KEY);
        if(staff == null) {
            throw new AssertionError("Null staff received");
        }

        TextView tvName = (TextView) findViewById(R.id.txtStaffName);
        TextView tvPosition = (TextView) findViewById(R.id.txtPosition);
        TextView tvDesc = (TextView) findViewById(R.id.txtDesc);
        ImageView staffImage = findViewById(R.id.imageStaff);

        tvName.setText(staff.getStaffName());
        tvPosition.setText(staff.getPosition());
        tvDesc.setText(staff.getDescription());

        InputStream inputStream = null;
        try {
            String imageFile = staff.getImage();
            inputStream = getAssets().open("staffimages/"+imageFile);
            Drawable d = Drawable.createFromStream(inputStream,null);
            staffImage.setImageDrawable(d);

        } catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            if(inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        Button btnBack = (Button) findViewById(R.id.btnBack);
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(StaffDetails.this, StaffList.class);
                startActivity(i);
            }
        });


    }
}
