package com.example.bookingnailserviceapp;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

public class DBOperationSupport {
    private static SQLiteDatabase wdb = null;
    private static DatabaseHelper db = null;

    public static SQLiteDatabase getWritable(Context context){
        if(db == null) {
            db = new DatabaseHelper(context);
        }
        if(wdb == null) {
            wdb = db.getWritableDatabase();
        }
        return wdb;
    }
    public static void displayAll(TableLayout theTable, SQLiteDatabase wdb, Context context, String selectQuery) {
        theTable.removeAllViews();
        try{
            Cursor cursor = wdb.rawQuery(selectQuery, null);
            String[] columnNames = cursor.getColumnNames();

            //looping through all rows and adding to list
            if(cursor != null)
            {
                cursor.moveToFirst();
                TextView data;
                TableRow row;

                // create the header
                row = new TableRow(context);
                for(int i = 0; i< columnNames.length; i++){
                    row.setPadding(2,2,2,2);
                    data = new TextView(context);
                    data.setTypeface(Typeface.DEFAULT_BOLD);
                    data.setText(columnNames[i]);
                    row.addView(data);
                }
                theTable.addView(row);

                do{
                    row = new TableRow(context);
                    row.setPadding(2,2,2,2);
                    for(int x = 0; x<cursor.getColumnCount();x++){
                        data = new TextView(context);
                        if(x == 0) {
                            data.setTypeface(Typeface.DEFAULT_BOLD);
                            data.setGravity(Gravity.CENTER_HORIZONTAL);
                        }
                        data.setText(cursor.getString(x));
                        row.addView(data);
                    }
                    theTable.addView(row);
                }
                while(cursor.moveToNext());
                theTable.setStretchAllColumns(true);
                cursor.close();
            }
        }
        catch (Exception ex) { }
    }
    public static  void close(){
        if(db != null)
        {
            db.close();
        }
    }

}
