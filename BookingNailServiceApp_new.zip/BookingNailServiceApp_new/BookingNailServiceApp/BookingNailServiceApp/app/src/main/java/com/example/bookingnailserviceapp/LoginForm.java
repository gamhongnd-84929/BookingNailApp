package com.example.bookingnailserviceapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginForm extends AppCompatActivity {
    DatabaseHelper myDB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_form);

        myDB = new DatabaseHelper(this);

        final EditText l_user = (EditText) findViewById(R.id.l_username);
        final EditText l_pass = (EditText) findViewById(R.id.l_password);
        TextView register = (TextView) findViewById(R.id.register_txt);

        Button login = (Button) findViewById(R.id.login_btn);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = l_user.getText().toString();
                String pass = l_pass.getText().toString();

                boolean result = myDB.checkUser(user,pass);
                if(result){
                    Intent intent = new Intent(LoginForm.this,MainActivity.class);
                    startActivity(intent);
                }
                else{
                    Toast.makeText(LoginForm.this,"Username or Password is invalid",Toast.LENGTH_LONG).show();
                }
            }
        });

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(LoginForm.this, MainActivity.class);
                startActivity(i);
            }
        });
    }
}
