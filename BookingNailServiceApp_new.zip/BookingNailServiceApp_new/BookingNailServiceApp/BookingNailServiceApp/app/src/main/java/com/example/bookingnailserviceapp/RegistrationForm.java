package com.example.bookingnailserviceapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class RegistrationForm extends AppCompatActivity {
    DatabaseHelper myDB;// create an instance
    EditText username,name,password,confirm;
    Button register_btn;
    Button view;
    Button delete;
    TextView login,error_username, error_name,error_pass,error_confirm;
    boolean isValid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration_form);

        myDB = new DatabaseHelper(this);//call the constructor

        username = (EditText) findViewById(R.id.username);
        name = (EditText) findViewById(R.id.name);
        password = (EditText) findViewById(R.id.password);
        confirm = (EditText) findViewById(R.id.confirm);

        delete = (Button) findViewById(R.id.delete_btn);
        view = (Button) findViewById(R.id.view);
        register_btn = (Button) findViewById(R.id.register_btn);

        login = (TextView) findViewById(R.id.login_txt);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(RegistrationForm.this, LoginForm.class);
                startActivity(it);
            }
        });

        AddData();
        viewAll();
        deleteData();
    }

    public void AddData() {
        isValid = true;
        error_username = (TextView) findViewById(R.id.error_username);
        error_name = (TextView) findViewById(R.id.error_name);
        error_pass = (TextView) findViewById(R.id.error_pass);
        error_confirm = (TextView) findViewById(R.id.error_confirm);

        register_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!(confirm.getText().toString().equals(password.getText().toString())) || confirm.getText().toString().isEmpty() || password.getText().toString().isEmpty()){
                    error_confirm.setText("* The password is invalid *");
                    error_pass.setText("* The password is invalid *");
                    isValid = false;
                }
                if(name.getText().toString().isEmpty()){
                    error_name.setText("* The name is invalid *");
                    isValid = false;
                }
                if(username.getText().toString().isEmpty()){
                    error_username.setText("* The username is invalid *");
                    isValid = false;
                }

                if(isValid){
                    boolean check = myDB.insertData(name.getText().toString(),username.getText().toString(),password.getText().toString());
                    if(check) {
                        Toast.makeText(RegistrationForm.this, "Successful", Toast.LENGTH_LONG).show();
                    }
                    else{
                        Toast.makeText(RegistrationForm.this,"Failed",Toast.LENGTH_LONG).show();
                    }

                }
            }
        });
    }

    public void viewAll() {
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor cursor = myDB.viewAll();
                if(cursor.getCount() == 0){
                    showData("Error","No Data Found");
                    return;
                }
                StringBuffer buffer = new StringBuffer();
                while(cursor.moveToNext()){
                    buffer.append("User Name :" + cursor.getString(0) + "\n");
                    buffer.append("Username :" + cursor.getString(1) + "\n");
                    buffer.append("Password :" + cursor.getString(2) + "\n\n");
                }

                showData("Data",buffer.toString());
            }
        });
    }

    public void showData(String key, String value) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(key);
        builder.setMessage(value);
        builder.show();
    }

    public void deleteData() {
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Integer deleteRow = myDB.deleteData(username.getText().toString());
                if(deleteRow > 0){
                    Toast.makeText(RegistrationForm.this, "Deleted Successful", Toast.LENGTH_LONG).show();
                }
                else{
                    Toast.makeText(RegistrationForm.this, "Deleted Fail", Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}
