package com.example.bookingnailserviceapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class ServicesList extends AppCompatActivity {
    private final String FILENAME = "Services.csv";
    private RecyclerView recyclerView;
    private ServiceAdapter serviceAdapter;
    private List<Service> serviceList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_service_list);

        ArrayList data  = readFile();
        //populating the RecyclerView
        recyclerView = (RecyclerView) findViewById(R.id.RView);
        serviceAdapter = new ServiceAdapter(this, serviceList);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(serviceAdapter);

        getTheData(data);

        Button btnBack = (Button) findViewById(R.id.btnBack);
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(ServicesList.this, MainActivity.class);

                startActivity(i);
            }
        });

        final ArrayList<String> serviceNames = new ArrayList<>();
        for(int i = 0; i<serviceList.size(); i++)
        {
            serviceNames.add(serviceList.get(i).getServiceName());
        }
    }


    private void getTheData(List<String> data) {
        Service service;
        String[] details;
        for(String s : data) {
            details = s.split(",");
            service = new Service(Integer.parseInt(details[0]),details[1],Integer.parseInt(details[2]),Double.parseDouble(details[3]),details[4],details[5]);
            serviceList.add(service);
        }
        serviceAdapter.notifyDataSetChanged();
    }


    private ArrayList readFile() {
        ArrayList list = new ArrayList<>();
        try{
            InputStream is  = getAssets().open(FILENAME);
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(is));

            String line;
            while((line = bufferedReader.readLine()) !=null)
            {
                list.add(line);
            }
            bufferedReader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return list;
    }
}
