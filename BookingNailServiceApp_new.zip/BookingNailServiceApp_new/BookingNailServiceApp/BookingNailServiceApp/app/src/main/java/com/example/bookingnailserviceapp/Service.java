package com.example.bookingnailserviceapp;

import android.os.Parcel;
import android.os.Parcelable;

public class Service implements Parcelable {

    private int serviceID;
    private String serviceName;
    private String description;
    private int duration;
    private double price;
    private String image;

    public Service(int id, String sName, int time, double p,String desc, String ima)
    {
        this.serviceID = id;
        this.serviceName = sName;
        this.description = desc;
        this.duration = time;
        this.price = p;
        this.image = ima;
    }



    public int getServiceID() {
        return serviceID;
    }
    public String getServiceName() {
        return serviceName;
    }
    public String getDescription() {
        return description;
    }
    public int getDuration() {
        return duration;
    }
    public double getPrice() {
        return price;
    }
    public String getImage() {return image;}


    protected Service(Parcel in) {
        serviceID = in.readInt();
        serviceName = in.readString();
        description = in.readString();
        duration = in.readInt();
        price = in.readDouble();
        image = in.readString();
    }

    public static final Creator<Service> CREATOR = new Creator<Service>() {
        @Override
        public Service createFromParcel(Parcel in) {
            return new Service(in);
        }

        @Override
        public Service[] newArray(int size) {
            return new Service[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(serviceID);
        dest.writeString(serviceName);
        dest.writeString(description);
        dest.writeInt(duration);
        dest.writeDouble(price);
        dest.writeString(image);
    }

//    public String toString() {
//        return serviceID + "-" + serviceName + "-" + description + "-" + duration + "-" + price;
//    }






}
