package com.example.bookingnailserviceapp;

import android.os.Parcel;
import android.os.Parcelable;

public class Staff implements Parcelable {
    private int staffID;
    private String staffName;
    private String position;
    private String description;
    private String image;

    public Staff(int id, String name, String pos, String desc, String ima)
    {
        this.staffID = id;
        this.staffName = name;
        this.position = pos;
        this.description = desc;
        this.image = ima;
    }
    public int getStaffID(){
        return staffID;
    }
    public String getStaffName() {
        return staffName;
    }
    public String getPosition(){
        return position;
    }
    public String getDescription() {
        return description;
    }
    public String getImage() {
        return image;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(this.staffID);
        dest.writeString(this.staffName);
        dest.writeString(this.position);
        dest.writeString(this.description);
        dest.writeString(this.image);
    }

    protected Staff(Parcel in) {
        this.staffID = in.readInt();
        this.staffName = in.readString();
        this.position = in.readString();
        this.description = in.readString();
        this.image = in.readString();
    }

    public static final Parcelable.Creator<Staff> CREATOR = new Parcelable.Creator<Staff>() {
        @Override
        public Staff createFromParcel(Parcel source) {
            return new Staff(source);
        }

        @Override
        public Staff[] newArray(int size) {
            return new Staff[size];
        }
    };
}
