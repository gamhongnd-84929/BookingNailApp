package com.example.bookingnailserviceapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "BookingNail.db";//db name
    public static final String TABLE_NAME_LI = "customer_table";//table name
    public static final String TABLE_NAME_SO = "Service_Order";//table name

    //column name
    public static final String COL_1 = "ID";
    public static final String COL_2 = "NAME";
    public static final String COL_3 = "USERNAME";
    public static final String COL_4 = "PASSWORD";

    public static final String C1 = "serviceOrderID";
    public static final String C2 = "serviceName";
    public static final String C3 = "staffName";
    public static final String C4 = "date";
    public static final String C5 = "startTime";
    public static final String C6 = "duration";
    public static final String C7 = "price";
    public static final String C8 = "ID";



    public DatabaseHelper(Context context) {
        //create database
        super(context, DATABASE_NAME, null, 1);

    }

    @Override
    public void onCreate(SQLiteDatabase dbs) {
        //create table into db
//        dbs.execSQL(TableDefinition.SQL_CREATE_SERVICE_ORDER);

        dbs.execSQL("CREATE TABLE " + TABLE_NAME_LI + "(ID INTEGER PRIMARY KEY AUTOINCREMENT, NAME VARCHAR(100), USERNAME VARCHAR(100) UNIQUE, PASSWORD VARCHAR(100))");//execute queries
        dbs.execSQL("CREATE TABLE " + TABLE_NAME_SO + "(serviceOrderID INTEGER , serviceName VARCHAR(100), staffName VARCHAR(100),date DATE,startTime HOUR, duration INTEGER,price DOUBLE, ID INTEGER,PRIMARY KEY(serviceOrderID,ID), FOREIGN KEY (ID) REFERENCES customer_table(ID))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase dbs, int oldVersion, int newVersion) {

        dbs.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME_LI);//drop the table in case of upgradation
        dbs.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME_SO);
        onCreate(dbs);// create table and database also
    }

    //insert database
    public boolean insertData(String NAME, String USERNAME, String PASSWORD){
        SQLiteDatabase dbs = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_2,NAME);
        contentValues.put(COL_3,USERNAME);
        contentValues.put(COL_4,PASSWORD);
        long result = dbs.insert(TABLE_NAME_LI,null,contentValues);//this method will return as minus 1 if it did not work
        //if works return a row value
        if(result == -1){
            return false;
        }
        else{
            return true;
        }
    }

    public boolean checkUser(String username,String password){
        String[] columns = {COL_1};
        SQLiteDatabase dbs = this.getReadableDatabase();
        String selection = COL_3 + " = ? " + " AND " + COL_4 + " = ? ";
        String[] selectionArg = {username,password};
        Cursor res = dbs.query(TABLE_NAME_LI,columns,selection,selectionArg,null, null, null);
        int count = res.getCount();
        if(count > 0){
            return true;//data exist
        }
        else{
            return false;
        }
    }

    //provide random read-write access to the result
    public Cursor viewAll() {
        SQLiteDatabase dbs = this.getWritableDatabase();
        Cursor result = dbs.rawQuery("SELECT NAME,USERNAME,PASSWORD FROM " + TABLE_NAME_LI,null);
        return result;
    }

    public Integer deleteData (String username){
        SQLiteDatabase dbs = this.getWritableDatabase();
        return dbs.delete(TABLE_NAME_LI," username = ?",new String[] {username});// retun number of effected row
    }
}
