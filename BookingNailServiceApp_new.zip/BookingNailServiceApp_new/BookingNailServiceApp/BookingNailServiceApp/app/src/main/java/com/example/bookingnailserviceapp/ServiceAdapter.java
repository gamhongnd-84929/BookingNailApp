package com.example.bookingnailserviceapp;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public class ServiceAdapter extends RecyclerView.Adapter<ServiceAdapter.ViewHolder> {
    public static final String SERVICE_KEY="service_key";
    private List<Service> serviceList;
    private Context serviceContext;

    public ServiceAdapter(Context context, List<Service> sList)
    {
        this.serviceContext = context;
        this.serviceList = sList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
       View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.service_layout,parent,false);

        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final  Service service = serviceList.get(position);
        try{
            holder.serviceName.setText(service.getServiceName());

            String serviceImageFile = service.getImage();
            InputStream is = serviceContext.getAssets().open("serviceimages/"+serviceImageFile);
            Drawable d = Drawable.createFromStream(is, null);
            holder.serviceImage.setImageDrawable(d);

        } catch (IOException e) {
            e.printStackTrace();
        }

        holder.serviceView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(serviceContext,ServiceDetails.class);
                intent.putExtra(SERVICE_KEY,service);
                serviceContext.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return serviceList.size();
    }


    public class ViewHolder  extends  RecyclerView.ViewHolder{
        public ImageView serviceImage;
        public TextView serviceName;
        public View serviceView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            serviceImage = (ImageView) itemView.findViewById(R.id.imageService);
            serviceName = (TextView) itemView.findViewById(R.id.txtSeviceName);

            serviceView = itemView;
        }
    }
}
