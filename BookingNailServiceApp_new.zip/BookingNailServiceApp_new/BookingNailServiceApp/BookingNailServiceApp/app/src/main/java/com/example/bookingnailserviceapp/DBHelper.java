//package com.example.bookingnailserviceapp;
//
//import android.app.ActionBar;
//import android.content.Context;
//import android.database.DatabaseErrorHandler;
//import android.database.sqlite.SQLiteDatabase;
//import android.database.sqlite.SQLiteOpenHelper;
//import android.util.Log;
//
//import androidx.annotation.NonNull;
//import androidx.annotation.Nullable;
//
//public class DBHelper extends SQLiteOpenHelper {
//
//    public static final int DATABASE_VERSION = 1;
//    public static final  String DATABASE_NAME = "BookingNail.db";
//
//
//    public DBHelper(@Nullable Context context) {
//        super(context, DATABASE_NAME, null, DATABASE_VERSION);
//    }
//
//    public void onOpen(SQLiteDatabase db) {
//        super.onOpen(db);
//    }
//
//    @Override
//    public void onCreate(SQLiteDatabase db) {
//        db.execSQL(TableDefinition.SQL_CREATE_SERVICE_ORDER);
//        Log.d("DBHelper","onCreate");
//    }
//
//
//    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
//        db.execSQL(TableDefinition.SQL_DELETE_SERVICE_ORDER);
//        Log.d("DBHelper","onUpgrade");
//        onCreate(db);
//    }
//    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
//        Log.d("DBHelper", "onDowngrade");
//        onUpgrade(db, oldVersion, newVersion);
//
//    }
//
//
//}
