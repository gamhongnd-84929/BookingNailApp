package com.example.bookingnailserviceapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.TimePicker;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class Booking extends AppCompatActivity {
    private final String FILESTAFF = "Staffs.csv";
    private final String FILESERVICE = "Services.csv";
    private List<Service> servicesList = new ArrayList<>();
    private List<Staff> staffList = new ArrayList<>();

    TableLayout theTable;
    SQLiteDatabase wdb;

    TextView tvHour, tvDate;

    private StaffAdapter staffAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking);


        // pick staff
//        ArrayList<String> staffNames = getIntent().getStringArrayListExtra("staffName");

        staffAdapter = new StaffAdapter(this, staffList);
        ArrayList staffData = readFileStaff();

        getStaffData(staffData);

        final ArrayList<String> staffNames = new ArrayList<>();
        for(int i = 0; i<staffList.size();i++) {
            staffNames.add(staffList.get(i).getStaffName());
        }

        final Spinner spStaff = (Spinner) findViewById(R.id.spStaff) ;
        ArrayAdapter<String> adapterStaff = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,staffNames);
        spStaff.setAdapter(adapterStaff);

        // pick service
        ArrayList serviceData = readFileService();

        getServiceData(serviceData);

        final ArrayList<String> serviceNames = new ArrayList<>();
        for(int i = 0; i<servicesList.size();i++) {
            serviceNames.add(servicesList.get(i).getServiceName());
        }
        final Spinner spService = (Spinner) findViewById(R.id.spService);
        ArrayAdapter<String> adapterService = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,serviceNames);
        spService.setAdapter(adapterService);

        //pick Date

        Button btnPickDate = (Button) findViewById(R.id.btnPickDate);
        btnPickDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                int duration = 1;

                Calendar c = Calendar.getInstance();
                int year = c.get(Calendar.YEAR);
                int month = c.get(Calendar.MONTH);
                int dayOfMonth = c.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog dpd = new DatePickerDialog(Booking.this, new DatePickerDialog.OnDateSetListener()
                {
                    public void onDateSet(DatePicker datePicker, int selectYear, int selectMonth, int selectDay) {
                        selectMonth = selectMonth + 1;
                        tvDate = (TextView) findViewById(R.id.txtDate);
                        tvDate.setText(selectMonth+"/"+selectDay+"/"+selectYear);
                    }
                }, year, month, dayOfMonth);
                dpd.show();
            }
        });

        //pick time


        Button btnPickHour = (Button) findViewById(R.id.btnPickHour);
        btnPickHour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                int duration = 1;

                Calendar c = Calendar.getInstance();
                int hour = c.get(Calendar.HOUR_OF_DAY);
                int minute = c.get(Calendar.MINUTE);

                TimePickerDialog tpd = new TimePickerDialog(Booking.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int selectHour, int selectMinute) {
                        tvHour = (TextView) findViewById(R.id.txtStart);
                        tvHour.setText(selectHour+":"+selectMinute);
                    }
                }, hour, minute, true);
                tpd.show();
            }
        });

        Button btnBack = (Button) findViewById(R.id.btnBack);
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Booking.this, MainActivity.class);
                startActivity(i);
            }
        });


        // show table service order
        wdb = DBOperationSupport.getWritable(this);
        theTable = (TableLayout) findViewById(R.id.bookTable);

        // select all query, use this one for check info too
        final  String selectQuery = "SELECT serviceName, staffName, date, startTime FROM Service_Order ";
        DBOperationSupport.displayAll(theTable, wdb, this, selectQuery); // display the row if any exist
        Button btnAdd = (Button) findViewById(R.id.btnAdd);
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView txtID = (TextView) findViewById(R.id.txtID);

                int staffPosition = spStaff.getSelectedItemPosition();
                int servicePosition = spService.getSelectedItemPosition();

                String staffName = staffNames.get(staffPosition);
                Log.d("StaffName:" , staffName);
                String serviceName = serviceNames.get(servicePosition);
                String date = tvDate.getText().toString();
                String startTime = tvHour.getText().toString();

                ContentValues values = new ContentValues();

                values.put("serviceName", serviceName);
                values.put("staffName", staffName);
                values.put("date",date);
                values.put("startTime", startTime);

                // all columns would have a value
                long newRowID = wdb.insert("Service_Order",null,values);
                txtID.setText("ServiceID: "+newRowID );
                DBOperationSupport.displayAll(theTable,wdb,Booking.this, selectQuery);

            }
        });


    }

    private void getStaffData(List<String> data) {
        Staff staff;
        String[] details;
        for(String s : data) {
            details = s.split(",");
            staff = new Staff(Integer.parseInt(details[0]),details[1],details[2],details[3],details[4]);
            staffList.add(staff);
        }
        staffAdapter.notifyDataSetChanged();
    }


    private void getServiceData(List<String> data)
    {
        Service service;
        String[] details;
        for(String s: data) {
            details = s.split(",");
            service = new Service(Integer.parseInt(details[0]),details[1],Integer.parseInt(details[2]),Double.parseDouble(details[3]),details[4],details[5]);
            servicesList.add(service);
        }
    }
    private ArrayList readFileStaff(){
        ArrayList stafflist = new ArrayList<>();
        try{
            InputStream is = getAssets().open(FILESTAFF);
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(is));
            String line;
            while ((line = bufferedReader.readLine()) != null)
            {
                stafflist.add(line);
            }
            bufferedReader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return  stafflist;
    }

    private ArrayList readFileService(){
        ArrayList servicelist = new ArrayList<>();
        try{
            InputStream is = getAssets().open(FILESERVICE);
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(is));
            String line;
            while ((line = bufferedReader.readLine()) != null)
            {
                servicelist.add(line);
            }
            bufferedReader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return  servicelist;
    }



}


