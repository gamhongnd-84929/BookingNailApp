package com.example.bookingnailserviceapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class StaffList extends AppCompatActivity {

    private final String FILENAME = "Staffs.csv";
    private RecyclerView recyclerView;
    private StaffAdapter staffAdapter;
    private List<Staff> sList = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staff_list);


        ArrayList data = readFile();

        // populating the RecyclerView
        recyclerView = (RecyclerView) findViewById(R.id.RView);
        staffAdapter = new StaffAdapter(this, sList);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(staffAdapter);

        getTheData(data);

        Button btnBack = (Button) findViewById(R.id.btnBack);
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(StaffList.this, MainActivity.class);
                startActivity(i);
            }
        });

        final ArrayList<String> staffNames = new ArrayList<>();
        for(int i = 0; i<sList.size();i++) {
            staffNames.add(sList.get(i).getStaffName());
        }




//        Button btnNext = (Button) findViewById(R.id.btnNext);
//        btnNext.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent i = new Intent(StaffList.this, Booking.class);
//                i.putStringArrayListExtra("staffName",staffNames);
//                startActivity(i);
//            }
//        });



    }

    private void getTheData(List<String> data) {
        Staff staff;
        String[] details;
        for(String s : data) {
            details = s.split(",");
            staff = new Staff(Integer.parseInt(details[0]),details[1],details[2],details[3],details[4]);
            sList.add(staff);
        }
        staffAdapter.notifyDataSetChanged();
    }


    private ArrayList readFile() {
        ArrayList list = new ArrayList<>();
        try{
            InputStream is  = getAssets().open(FILENAME);
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(is));

            String line;
            while((line = bufferedReader.readLine()) !=null)
            {
             list.add(line);
            }
            bufferedReader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return list;
    }
}
