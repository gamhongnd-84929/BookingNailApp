package com.example.bookingnailserviceapp;

public class TableDefinition {
//    public static final  String SQL_CREATE_STAFF =
//            "CREATE TABLE Staff(staffID INTEGER PRIMARY KEY, staffName TEXT, staffRoll TEXT)";
//    public static final String SQL_DELETE_STAFF =
//            "DROP TABLE IF EXISTS Staff";
//    public static final String SQL_CREATE_SERVICE =
//            "CREATE TABLE Service(serviceID INTEGER PRIMARY KEY, serviceName TEXT, price DOUBLE, description TEXT, duration INTERVAL DAY TO SECOND)";
//    public static final String SQL_DELETE_SERVICE =
//            "DROP TABLE IF EXISTS Service";
//
//    public static final String SQL_CREATE_STAFF_WORKING_HOUR =
//            "CREATE TABLE Staff_Working_Hour(staffID INTEGER, " +
//                    "date DATE, startTime HOUR, duration INTERVAL DAY TO SECOND, " +
//                    "PRIMARY KEY(staffID, data, startTime, duration), FOREIGN KEY(staffID) REFERENCES STAFF(staffID))";
//    public static final String SQL_DELETE_STAFF_WROKING_HOUR =
//            "DROP TABLE IF EXISTS Staff_Working_Hour";
//
//    public static final String SQL_CREATE_STAFF_DATE =
//            "CREATE TABLE Staff_Date(staffID INTEGER, date DATE, PRIMARY KEY(staffID, date), FOREIGN KEY(staffID) REFERENCES STAFF(staffID) ON DELETE CASCADE)";
//    public static final String SQL_DELETE_STAFF_DATE =
//            "DROP TABLE IF EXISTS Staff_Date";

    public static final String SQL_CREATE_SERVICE_ORDER =
            "CREATE TABLE Service_Order(serviceOrderID INTEGER PRIMARY KEY, " +
                    "serviceName TEXT, staffName TEXT, date DATE, startTime HOUR, duration INT, price DOUBLE, ID INTEGER," +
                    "FOREIGN KEY(ID) REFERENCES customer_table(ID))";

    public static final String SQL_DELETE_SERVICE_ORDER =
            "DROP TABLE IF EXISTS Service_Order";

}
