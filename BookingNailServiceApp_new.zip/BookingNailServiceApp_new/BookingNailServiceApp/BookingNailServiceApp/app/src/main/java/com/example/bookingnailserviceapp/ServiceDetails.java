package com.example.bookingnailserviceapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;

public class ServiceDetails extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_service_details);

        Service service = getIntent().getExtras().getParcelable(ServiceAdapter.SERVICE_KEY);
        if(service == null) {
            throw new AssertionError("Null service received");
        }

        TextView tvName = (TextView) findViewById(R.id.txtSeviceName);
        TextView tvprice = (TextView) findViewById(R.id.txtPrice);
        TextView tvDesc = (TextView) findViewById(R.id.txtDesc);
        ImageView serviceImage = findViewById(R.id.imageService);

        tvName.setText(service.getServiceName());
        tvprice.setText(service.getPrice()+"");
        tvDesc.setText(service.getDescription());

        InputStream inputStream = null;
        try {
            String serviceImageFile = service.getImage();
            inputStream = getAssets().open("serviceimages/"+serviceImageFile);
            Drawable d = Drawable.createFromStream(inputStream,null);
            serviceImage.setImageDrawable(d);

        } catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            if(inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        Button btnBack = (Button) findViewById(R.id.btnBack);
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(ServiceDetails.this, ServicesList.class);
                startActivity(i);
            }
        });

    }
}
